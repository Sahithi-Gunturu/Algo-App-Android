package com.example.project1

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class thirdAcinsertion: AppCompatActivity() {
    private val strf = StringBuilder()
    private var c:Int = 1;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.third_insertion)
        getSupportActionBar()?.setTitle("MY PROJECT")
        val button = findViewById<Button>(R.id.moveback)
        button.setOnClickListener(){
            finish()
        }
        val bundle: Bundle? = intent.extras
        val string = bundle?.get("str")
        val arr: List<String> = string.toString().split(",")
        val arrayList = ArrayList<Int>()
        for (i in arr.indices) {
            arrayList.add(arr[i].toInt())
        }
        strf.append("Input : " + arrayList.joinToString(" ") + "\n\n\n")
        insertionsort(arrayList)

        val output = findViewById<TextView>(R.id.output)
        output.setText(strf);

    }
    private fun insertionsort(items:MutableList<Int>){
        if (items.isEmpty() || items.size<2){
            return
        }
        for (count in 1..items.count() - 1){
            val item = items[count]
            var i = count
            while (i>0 && item < items[i - 1]){
                items[i] = items[i - 1]
                i -= 1
            }
            items[i] = item

            strf.append("pass " + c.toString()+ " : " + items.joinToString(" ") + "\n\n")
            c +=1
        }
        return
    }
}