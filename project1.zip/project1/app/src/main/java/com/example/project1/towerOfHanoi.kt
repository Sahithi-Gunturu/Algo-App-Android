package com.example.project1

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class towerOfHanoi: AppCompatActivity() {
    var strf = StringBuilder()
    var count = 1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tower_of_hanoi)
        getSupportActionBar()?.setTitle("MY PROJECT")

        val input = findViewById<EditText>(R.id.input)
        val enter = findViewById<Button>(R.id.enter)
        val backbtn = findViewById<Button>(R.id.moveback)
        val output = findViewById<TextView>(R.id.output)

        enter.setOnClickListener(){
            val a = input.text.toString()
            val disks = a.toInt()
            val minmoves = Math.pow(2.0,disks.toDouble()) - 1
            val min = minmoves.toInt()
            strf.append("MINIMUM NUMBER OF MOVES: $min\n\n")
            hanoiTowers(disks)
            output.setText(strf)

//            Toast.makeText(applicationContext,disks.toString(), Toast.LENGTH_SHORT).show()
        }


        backbtn.setOnClickListener(){finish()}
    }

    fun hanoiTowers(n : Int) {
        solveHanoi(n, 'A', 'C', 'B')
    }

    private fun solveHanoi(h: Int, fDisk: Char, tDisk: Char, wDisk: Char)
    {
        if(h >= 1) {
            solveHanoi(h - 1, fDisk, wDisk, tDisk)
            strf.append("$count: Move disk from $fDisk to $tDisk\n")
            count+=1
            solveHanoi(h - 1, wDisk, tDisk, fDisk)
        }
    }
}