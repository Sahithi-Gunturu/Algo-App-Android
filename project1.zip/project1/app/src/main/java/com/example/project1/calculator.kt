package com.example.project1

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.calculator.*
import org.mariuszgromada.math.mxparser.Expression
import java.text.DecimalFormat
import java.util.*


class calculator : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.calculator)
        getSupportActionBar()?.setTitle("MY PROJECT")

        button_clear.setOnClickListener{
            inputscreen.text= ""
            outputscreen.text=""
        }

        button_back.setOnClickListener{
            if ((inputscreen.text.toString()).isEmpty()) {
                inputscreen.text=""
            }
            else
                inputscreen.text= inputscreen.text.toString().substring(0, inputscreen.text.toString().length-1)
        }

        button_lp.setOnClickListener{
            inputscreen.text = addInput("(")
        }
        button_rp.setOnClickListener{
            inputscreen.text = addInput(")")
        }
        button_0.setOnClickListener{
            inputscreen.text = addInput("0")
        }
        button_1.setOnClickListener{
            inputscreen.text = addInput("1")
        }

        button_2.setOnClickListener{
            inputscreen.text = addInput("2")
        }
        button_3.setOnClickListener{
            inputscreen.text = addInput("3")
        }
        button_4.setOnClickListener{
            inputscreen.text = addInput("4")
        }
        button_5.setOnClickListener{
            inputscreen.text = addInput("5")

        }
        button_6.setOnClickListener{
            inputscreen.text = addInput("6")
        }
        button_7.setOnClickListener{
            inputscreen.text = addInput("7")
        }
        button_8.setOnClickListener{
            inputscreen.text = addInput("8")
        }
        button_9.setOnClickListener{
            inputscreen.text = addInput("9")
        }
        button_decimal.setOnClickListener{
            inputscreen.text = addInput(".")

        }
        button_mply.setOnClickListener{
            inputscreen.text = addInput("*")
        }

        button_add.setOnClickListener{
            inputscreen.text = addInput("+")
        }
        button_sub.setOnClickListener{
            inputscreen.text = addInput("-")

        }
        button_divide.setOnClickListener{
            inputscreen.text = addInput("/")
        }

        button_equalsto.setOnClickListener{
//            inputscreen.text = ""
            showresult()
        }





    }




    private fun addInput(buttonvalue:String):String{
        if(outputscreen.text!="") {
            val out=outputscreen.text;
            outputscreen.text = ""
            return "$out$buttonvalue"

        }
        return "${inputscreen.text}$buttonvalue"
    }

    private fun showresult(){

        val expression= inputscreen.text.toString()
        val result = Expression(expression).calculate();
        if(!result.isNaN())
            outputscreen.text=DecimalFormat("0.######").format(result).toString()

        else{
            Toast.makeText(this , "enter valid expression", Toast.LENGTH_SHORT).show()
        }
//        val res=infixToPostfix(expression)
//        val result=evaluatePostfix(res)
        outputscreen.text=DecimalFormat("0.######").format(result).toString()

        outputscreen.setTextColor(ContextCompat.getColor(this, R.color.green))
        inputscreen.text=""
    }




    private fun rank(op: Char): Int {
        return when (op) {
            '+', '-' -> 1
            '*', '/' -> 2
            else -> 0
        }
    }
    private fun infixToPostfix(infixExp: String): Queue<String> {
        val ans: Queue<String> = LinkedList()
        val stack: Stack<Char> = Stack()
        var i = 0
        val len = infixExp.length
        while (i < len) {
            val num = StringBuilder()
            while (i < len && infixExp[i].isDigit()) num.append(infixExp[i++])
            if (num.isNotEmpty()) ans.add(num.toString())
            if (i == len) break
            val ch = infixExp[i++]
            when {
                ch.isWhitespace() -> {}
                else -> {
                    while (stack.isNotEmpty() && rank(stack.peek()) >= rank(ch)) {
                        ans.add("${stack.pop()}")
                    }
                    stack.push(ch)
                }
            }
        }
        while (stack.isNotEmpty()) {
            ans.add("${stack.pop()}")
        }
        return ans
    }

    private fun evaluatePostfix(postfix: Queue<String>): Int {
        val stack: Stack<Long> = Stack()
        for (exp in postfix) {
            if (exp[0].isDigit())
                stack.push(exp.toLong())
            else {
                val b = stack.pop()
                val a = stack.pop()
                when (exp[0]) {
                    '+' -> stack.push(a + b)
                    '-' -> stack.push(a - b)
                    '*' -> stack.push(a * b)
                    else -> stack.push(a / b)
                }
            }
        }
        return stack.pop().toInt()
    }


}
