package com.example.project1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import org.w3c.dom.Text
import java.util.*
import kotlin.collections.ArrayList

class thirdAcbubble : AppCompatActivity() {
    private val strf = StringBuilder()
    private var count:Int = 1;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.third_bubble)
        getSupportActionBar()?.setTitle("MY PROJECT")
        val button =findViewById<Button>(R.id.moveback)
        val bundle: Bundle? = intent.extras
        val string = bundle?.get("str")

            val arr: List<String> = string.toString().split(",")
            val arrayList = ArrayList<Int>()
            for (i in arr.indices) {
                arrayList.add(arr[i].toInt())
            }
            val length:Int = arrayList.size
            strf.append("Input : " + arrayList.joinToString(" ") + "\n\n\n")
            bubblesort(arrayList, length)

            val output = findViewById<TextView>(R.id.output)
            output.setText(strf);

        button.setOnClickListener() {
            finish()
        }
    }

    private fun  bubblesort(arr : ArrayList<Int>, length : Int) {
        if(length < 2) return
        for(i in 0 until length-1){
            if(arr[i] > arr[i+1]){
                val temp = arr[i+1]
                arr[i+1] = arr[i]
                arr[i] = temp
            }
        }
        strf.append("pass " + count.toString() + " : " + arr.joinToString(" ")+"\n\n")
        count += 1
        return bubblesort(arr, length - 1)
    }
}