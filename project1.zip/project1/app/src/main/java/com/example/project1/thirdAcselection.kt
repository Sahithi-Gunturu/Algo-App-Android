package com.example.project1

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.second_activity.*

class thirdAcselection:AppCompatActivity() {
    private val strf = StringBuilder()
    private var count:Int = 1;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.third_selection)
        getSupportActionBar()?.setTitle("MY PROJECT")
        val button = findViewById<Button>(R.id.moveback)



        val bundle: Bundle? = intent.extras
        val string = bundle?.get("str")
        val arr: List<String> = string.toString().split(",")
        val arrayList = ArrayList<Int>()
        for (i in arr.indices) {
            arrayList.add(arr[i].toInt())
        }
        strf.append("Input : " + arrayList.joinToString(" ") + "\n\n\n")
        selectionsort(arrayList)

        val output = findViewById<TextView>(R.id.output)
        output.setText(strf);
        button.setOnClickListener(){
            finish()
        }

    }

    private fun selectionsort(a:ArrayList<Int>){
        var min:Int
        for (i in 0 until a.size) {
            min = i
            for (j in (i + 1) until a.size) {
                if (a[j] < a[min]) {
                    min = j
                }
            }
            swap(a, min, i)
            strf.append("pass " + count.toString() + " : " +a.joinToString()+"\n\n")
            count+=1
        }
    }
    private fun swap(a : ArrayList<Int>, b: Int, c:Int) {
        val temp = a[b]
        a[b] = a[c]
        a[c] = temp
    }
}