package com.example.project1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.second_activity.*

class SecondActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.second_activity)
        getSupportActionBar()?.setTitle("My project")
        val bubblesortbtn = findViewById<Button>(R.id.bubblesort)
        val input = findViewById<EditText>(R.id.input)
        val insertionsortbtn =findViewById<Button>(R.id.insertionsort)
        val mergesortbtn = findViewById<Button>(R.id.mergesort)
        val selectionsortbtn = findViewById<Button>(R.id.selectionsort)
        val movebackbtn = findViewById<Button>(R.id.movebackbtn)

        val bundle: Bundle? = intent.extras
        val string = bundle?.get("str1")
        if(string == null) input.setText("")
        else input.setText(string.toString())

        bubblesortbtn.setOnClickListener(){
            intent = Intent(this,thirdAcbubble::class.java)
            intent.putExtra("str" , input.text)
            startActivity(intent)
        }
        mergesortbtn.setOnClickListener(){
            intent = Intent(this,thirdAcmerge::class.java)
            intent.putExtra("str",input.text)
            startActivity(intent)
        }

        insertionsortbtn.setOnClickListener(){
            intent = Intent(this,thirdAcinsertion::class.java)
            intent.putExtra("str",input.text)
            startActivity(intent)
        }
        selectionsortbtn.setOnClickListener(){
            intent = Intent(this,thirdAcselection::class.java)
            intent.putExtra("str",input.text)
            startActivity(intent)
        }
        quicksort.setOnClickListener(){
            intent = Intent(this,thirdAcquick::class.java)
            intent.putExtra("str",input.text)
            startActivity(intent)
        }












        movebackbtn.setOnClickListener(){
            intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }



    }
}