package com.example.project1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class thirdAcmerge: AppCompatActivity() {
    private val strf = StringBuilder()
    private var count:Int = 1;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.third_merge)
        getSupportActionBar()?.setTitle("MY PROJECT")
        val button =findViewById<Button>(R.id.moveback)
        val bundle: Bundle? = intent.extras
        val string = bundle?.get("str")

        val arr: List<String> = string.toString().split(",")
        val arrayList = ArrayList<Int>()
        for (i in arr.indices) {
            arrayList.add(arr[i].toInt())
        }
        val length:Int = arrayList.size
        strf.append("Input : " + arrayList.joinToString(" ") + "\n\n\n")

        val a = mergeSort(arrayList)

        val output = findViewById<TextView>(R.id.output)
        output.setText(strf);
//        Toast.makeText(applicationContext,"BUBBLE SORT", Toast.LENGTH_SHORT).show()

        button.setOnClickListener(){
            finish()
        }
    }

       private fun mergeSort(list: List<Int>): List<Int> {
         if (list.size <= 1) return list

          val middle = list.size / 2
          var left = list.subList(0,middle)
          var right = list.subList(middle,list.size)
          strf.append(left.joinToString(" ") + "   " + right.joinToString(" ")+"\n")
          return merge(mergeSort(left), mergeSort(right))

}
       private fun merge(left: List<Int>, right: List<Int>): List<Int>  {

           var indexLeft = 0
           var indexRight = 0
           var newList : MutableList<Int> = mutableListOf()

        while (indexLeft < left.count() && indexRight < right.count()) {
            if (left[indexLeft] <= right[indexRight]) {
                newList.add(left[indexLeft])
                indexLeft++
            } else {
                newList.add(right[indexRight])
                indexRight++
            }
        }

        while (indexLeft < left.size) {
            newList.add(left[indexLeft])
            indexLeft++
        }

        while (indexRight < right.size) {
            newList.add(right[indexRight])
            indexRight++
        }
       strf.append("pass " + count.toString() + " : " + newList.joinToString(" ")+"\n\n")
           count+=1
           return newList;
    }
}