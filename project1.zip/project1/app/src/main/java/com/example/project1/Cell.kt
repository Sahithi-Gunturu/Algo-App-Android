package com.example.project1
data class Cell(val i: Int, val j: Int)
