package com.example.project1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        getSupportActionBar()?.setTitle("My project")
        val btn1 = findViewById<Button>(R.id.btn1)
        btn1.setOnClickListener(){
            val intent = Intent(this,SecondActivity::class.java)
            startActivity(intent)
        }
        val tictac = findViewById<Button>(R.id.btn2)
        tictac.setOnClickListener(){
            intent = Intent(this,tic_tac_toe::class.java)
            startActivity(intent)
        }
        val gcdlcmbtn = findViewById<Button>(R.id.btn3)
        gcdlcmbtn.setOnClickListener(){
            intent = Intent(this,gcdlcm::class.java)
            startActivity(intent)
        }
        val tohbtn = findViewById<Button>(R.id.btn4)
        tohbtn.setOnClickListener(){
            intent = Intent(this,towerOfHanoi::class.java)
            startActivity(intent)
        }
        val calcbtn =findViewById<Button>(R.id.btn6)
            calcbtn.setOnClickListener(){
            intent = Intent(this,calculator::class.java)
            startActivity(intent)
        }


    }
}