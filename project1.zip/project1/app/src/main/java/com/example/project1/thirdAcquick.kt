package com.example.project1

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class thirdAcquick : AppCompatActivity() {
    private val strf = StringBuilder()
    private var count:Int = 1;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.third_quick)
        getSupportActionBar()?.setTitle("MY PROJECT")
        val button = findViewById<Button>(R.id.movebackbtn)
        val bundle: Bundle? = intent.extras
        val string = bundle?.get("str")
        val arr: List<String> = string.toString().split(",")
        val arrayList = ArrayList<Int>()
        for (i in arr.indices) {
            arrayList.add(arr[i].toInt())
        }
        strf.append("Input : " + arrayList.joinToString(" ") + "\n\n\n")
        quickSort(arrayList,0,arrayList.size-1)

        val output = findViewById<TextView>(R.id.output)
        output.setText(strf);
        button.setOnClickListener(){
            finish()
        }

    }

    private fun quickSort(array: ArrayList<Int>, left: Int, right: Int) {
        val index = partition (array, left, right)
        if(left < index-1) { // 2) Sorting left half
            quickSort(array, left, index-1)
        }

        if(index < right) { // 3) Sorting right half
            quickSort(array,index, right)
        }

    }

    private fun partition(array: ArrayList<Int>, l: Int, r: Int): Int {
        var left = l
        var right = r
        val pivot = array[(left + right)/2] // 4) Pivot Point
        while (left <= right) {
            while (array[left] < pivot) left++ // 5) Find the elements on left that should be on right

            while (array[right] > pivot) right-- // 6) Find the elements on right that should be on left

            // 7) Swap elements, and move left and right indices
            if (left <= right) {
                swapArray(array, left,right)
                left++
                right--
            }
        }
        strf.append("pass " + count.toString() + " : " + array.joinToString()+"\n\n")
        count+=1
        return left
    }

    fun swapArray(a: ArrayList<Int>, b: Int, c: Int) {
        val temp = a[b]
        a[b] = a[c]
        a[c] = temp
    }
}