package com.example.project1

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class gcdlcm : AppCompatActivity() {
    var strf = StringBuilder()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.gcd_lcm)
        getSupportActionBar()?.setTitle("My project")

        val input1 = findViewById<EditText>(R.id.input1)
        val output = findViewById<TextView>(R.id.output)
        val gcdbtn = findViewById<Button>(R.id.getgcd)

        gcdbtn.setOnClickListener(){
            val strinput = input1.text
            val arr: List<String> = strinput.toString().split(",")
            val arrayList = ArrayList<Int>()
            for (i in arr.indices) {
                arrayList.add(arr[i].toInt())
            }
            gcd(arrayList)
            lcm(arrayList)
            output.setText(strf)
            strf.setLength(0)
        }

    }


    private fun gcd(arr : ArrayList<Int>){
        var result : Int= arr[0]
        for(i in arr.indices){
            result = gcdcal(result , arr[i])
        }
        strf.append("GCD : " + result.toString()+"\n")
    }

    private fun gcdcal(a : Int , b:Int) : Int{
        if(a == 0) return b
        return gcdcal(b%a, a)
    }

    private fun lcm(arr : ArrayList<Int>){
        var resultlcm = arr[0]
        for(i in arr.indices){
            resultlcm = (arr[i] * resultlcm) / gcdcal(arr[i] , resultlcm)
        }
        strf.append("LCM : " + resultlcm.toString())
    }

}